-- BÉNIN MARKET : migration additive. Ne supprime aucune annonce.
-- À examiner sur une copie de votre projet avant exécution en production.
create extension if not exists pgcrypto;
alter table public.ads add column if not exists condition text;
alter table public.messages add column if not exists image_path text;
alter table public.profiles add column if not exists last_seen_at timestamptz;

create table if not exists public.professional_verifications (
 user_id uuid primary key references auth.users(id) on delete cascade,
 ifu text not null, ifu_path text not null, identity_path text not null,
 status text not null default 'pending' check(status in ('pending','approved','rejected')),
 created_at timestamptz not null default now(), reviewed_at timestamptz
);
create table if not exists public.search_alerts (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 query text default '', commune text default 'Toutes les communes', min_price numeric, max_price numeric,
 condition text default 'all', seller_type text default 'all', created_at timestamptz default now()
);
create table if not exists public.message_reports (
 id uuid primary key default gen_random_uuid(), reporter_id uuid not null references auth.users(id),
 reported_user_id uuid not null references auth.users(id), reason text not null,
 created_at timestamptz default now()
);
create table if not exists public.seller_reviews (
 id uuid primary key default gen_random_uuid(), seller_id uuid not null references auth.users(id),
 reviewer_id uuid not null references auth.users(id), rating int not null check(rating between 1 and 5),
 comment text default '', created_at timestamptz default now(), unique(seller_id,reviewer_id),
 check(seller_id <> reviewer_id)
);
create table if not exists public.courier_profiles (
 user_id uuid primary key references auth.users(id) on delete cascade,
 business_name text not null, phone text not null, city text not null, vehicle text not null,
 status text not null default 'pending' check(status in ('pending','approved','rejected')),
 created_at timestamptz default now()
);
create table if not exists public.sale_confirmations (
 id uuid primary key default gen_random_uuid(), ad_id uuid not null,
 buyer_id uuid not null references auth.users(id), seller_id uuid not null references auth.users(id),
 buyer_approved boolean not null default false, seller_approved boolean not null default false,
 video_status text not null default 'pending' check(video_status in ('pending','approved','rejected')),
 created_at timestamptz default now(), unique(ad_id,buyer_id),check(buyer_id <> seller_id)
);
-- Activer RLS : les tables de vérification et de signalement restent privées.
alter table public.professional_verifications enable row level security;
alter table public.search_alerts enable row level security;
alter table public.message_reports enable row level security;
alter table public.seller_reviews enable row level security;
alter table public.courier_profiles enable row level security;
alter table public.sale_confirmations enable row level security;

create policy "verification_owner_read" on public.professional_verifications for select to authenticated using(user_id=auth.uid());
create policy "verification_owner_create" on public.professional_verifications for insert to authenticated with check(user_id=auth.uid() and status='pending');
-- Pas de mise à jour client du statut de vérification : l'admin doit utiliser un backend sécurisé.
create policy "alerts_owner_all" on public.search_alerts for all to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
create policy "reports_owner_create" on public.message_reports for insert to authenticated with check(reporter_id=auth.uid() and reporter_id<>reported_user_id);
create policy "reviews_public_read" on public.seller_reviews for select to anon,authenticated using(true);
-- La création d'avis doit être accordée uniquement après vérification d'une transaction côté serveur.
create policy "courier_approved_public_read" on public.courier_profiles for select to anon,authenticated using(status='approved' or user_id=auth.uid());
create policy "courier_owner_create" on public.courier_profiles for insert to authenticated with check(user_id=auth.uid() and status='pending');
create policy "sales_participants_read" on public.sale_confirmations for select to authenticated using(buyer_id=auth.uid() or seller_id=auth.uid());
-- Pas d'INSERT/UPDATE direct : prévoir des fonctions RPC SECURITY DEFINER contrôlées,
-- qui valident la propriété de l'annonce, l'accord des deux parties et le contrôle vidéo.

-- Stockage privé des documents et des images de messagerie.
insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('verification-docs','verification-docs',false,5242880,array['image/jpeg','image/png','image/webp','application/pdf'])
on conflict(id) do nothing;
insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('chat-images','chat-images',false,5242880,array['image/jpeg','image/png','image/webp'])
on conflict(id) do nothing;
create policy "verification_upload_own_folder" on storage.objects for insert to authenticated
with check(bucket_id='verification-docs' and (storage.foldername(name))[1]=auth.uid()::text);
create policy "chat_upload_own_folder" on storage.objects for insert to authenticated
with check(bucket_id='chat-images' and (storage.foldername(name))[1]=auth.uid()::text);
-- Lecture des pièces d'identité : uniquement via backend admin autorisé (service role).
-- Lecture des images de chat : fournir des URL signées depuis un backend qui vérifie
-- que l'utilisateur est expéditeur ou destinataire. Ne PAS rendre le bucket public.
-- Les statuts, avis après achat et confirmations doivent être validés par backend.
