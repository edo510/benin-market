-- BÉNIN MARKET : ADMINISTRATION (migration additive)
-- Exécuter APRÈS Benin_Market_MAJ_Supabase.sql, dans Supabase SQL Editor.
-- Aucun DELETE / TRUNCATE des annonces, profils ou messages.
create table if not exists public.bm_admin_roles (
 user_id uuid primary key references auth.users(id) on delete cascade,
 created_at timestamptz not null default now()
);
alter table public.bm_admin_roles enable row level security;
-- Aucune policy d'écriture client : rôles accordés uniquement via SQL Editor.
create table if not exists public.bm_admin_audit (
 id bigint generated always as identity primary key,
 admin_id uuid not null references auth.users(id),
 entity_type text not null, entity_id text not null,
 action text not null, reason text,
 created_at timestamptz not null default now()
);
alter table public.bm_admin_audit enable row level security;
create or replace function public.bm_is_admin() returns boolean
language sql stable security definer set search_path = '' as $$
 select exists(select 1 from public.bm_admin_roles where user_id = (select auth.uid()));
$$;
revoke all on function public.bm_is_admin() from public;
grant execute on function public.bm_is_admin() to authenticated;

create or replace function public.bm_admin_overview()
returns jsonb language plpgsql security definer set search_path = '' as $$
declare result jsonb;
begin
 if not public.bm_is_admin() then raise exception 'Accès administrateur refusé'; end if;
 select jsonb_build_object(
 'ads', (select count(*) from public.ads),
 'professional_pending', (select count(*) from public.professional_verifications where status='pending'),
 'courier_pending', (select count(*) from public.courier_profiles where status='pending'),
 'message_reports', (select count(*) from public.message_reports),
 'professionals', coalesce((select jsonb_agg(to_jsonb(x)) from
  (select user_id,ifu,status,created_at,ifu_path,identity_path from public.professional_verifications order by created_at desc limit 60) x),'[]'::jsonb),
 'couriers', coalesce((select jsonb_agg(to_jsonb(x)) from
  (select user_id,business_name,city,vehicle,status,created_at from public.courier_profiles order by created_at desc limit 60) x),'[]'::jsonb),
 'reports', coalesce((select jsonb_agg(to_jsonb(x)) from
  (select id,reporter_id,reported_user_id,reason,created_at from public.message_reports order by created_at desc limit 60) x),'[]'::jsonb),
 'audit', coalesce((select jsonb_agg(to_jsonb(x)) from
  (select action,entity_type,entity_id,created_at from public.bm_admin_audit order by created_at desc limit 20) x),'[]'::jsonb)
 ) into result;
 return result;
end $$;
revoke all on function public.bm_admin_overview() from public;
grant execute on function public.bm_admin_overview() to authenticated;

create or replace function public.bm_admin_review(
 p_kind text, p_id text, p_status text, p_reason text default null)
returns void language plpgsql security definer set search_path = '' as $$
declare affected integer;
begin
 if not public.bm_is_admin() then raise exception 'Accès administrateur refusé'; end if;
 if p_kind not in ('professional','courier') or p_status not in ('approved','rejected') then
  raise exception 'Action invalide'; end if;
 if p_kind='professional' then
  update public.professional_verifications set status=p_status,reviewed_at=now()
  where user_id=p_id::uuid and status='pending';
 else
  update public.courier_profiles set status=p_status
  where user_id=p_id::uuid and status='pending';
 end if;
 get diagnostics affected = row_count;
 if affected<>1 then raise exception 'Demande introuvable ou déjà traitée'; end if;
 insert into public.bm_admin_audit(admin_id,entity_type,entity_id,action,reason)
 values(auth.uid(),p_kind,p_id,p_status,left(coalesce(p_reason,''),1000));
end $$;
revoke all on function public.bm_admin_review(text,text,text,text) from public;
grant execute on function public.bm_admin_review(text,text,text,text) to authenticated;

create or replace function public.bm_admin_resolve_report(p_id uuid,p_reason text default null)
returns void language plpgsql security definer set search_path = '' as $$
declare affected integer;
begin
 if not public.bm_is_admin() then raise exception 'Accès administrateur refusé'; end if;
 delete from public.message_reports where id=p_id;
 get diagnostics affected = row_count;
 if affected<>1 then raise exception 'Signalement introuvable'; end if;
 insert into public.bm_admin_audit(admin_id,entity_type,entity_id,action,reason)
 values(auth.uid(),'message_report',p_id::text,'resolved',left(coalesce(p_reason,''),1000));
end $$;
revoke all on function public.bm_admin_resolve_report(uuid,text) from public;
grant execute on function public.bm_admin_resolve_report(uuid,text) to authenticated;

-- IMPORTANT : après création de VOTRE compte, remplacez l'adresse ci-dessous
-- et exécutez CETTE instruction séparément dans SQL Editor :
-- insert into public.bm_admin_roles(user_id)
-- select id from auth.users where email='VOTRE_EMAIL_ADMIN@example.com'
-- on conflict (user_id) do nothing;
-- N'ajoutez jamais la clé service_role dans le HTML.
-- Les pièces d'identité restent privées : leur visualisation exige
-- une Edge Function avec vérification bm_is_admin() et URL signée courte.
