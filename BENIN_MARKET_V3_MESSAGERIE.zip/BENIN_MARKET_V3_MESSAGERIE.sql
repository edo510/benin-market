-- BENIN MARKET V3 : MESSAGERIE PRIVEE + SIGNALISATION D'APPELS
-- Migration additive. Executer dans Supabase SQL Editor apres V2.
-- La table public.messages doit deja exister avec id, sender_id, recipient_id.

CREATE TABLE IF NOT EXISTS public.bm_chat_attachments (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 message_id text NOT NULL,
 sender_id uuid NOT NULL REFERENCES auth.users(id),
 recipient_id uuid NOT NULL REFERENCES auth.users(id),
 storage_path text NOT NULL UNIQUE,
 mime_type text NOT NULL CHECK(mime_type IN ('image/jpeg','image/png','image/webp','video/mp4','video/webm')),
 size_bytes bigint NOT NULL CHECK(size_bytes BETWEEN 1 AND 31457280),
 created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.bm_chat_attachments ENABLE ROW LEVEL SECURITY;
CREATE INDEX IF NOT EXISTS bm_chat_attach_message_idx ON public.bm_chat_attachments(message_id);

CREATE OR REPLACE FUNCTION public.bm_chat_message_participant(p_message text)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = '' AS $$
 SELECT EXISTS(SELECT 1 FROM public.messages m WHERE m.id::text=p_message
 AND (m.sender_id=(SELECT auth.uid()) OR m.recipient_id=(SELECT auth.uid())));
$$;
REVOKE ALL ON FUNCTION public.bm_chat_message_participant(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.bm_chat_message_participant(text) TO authenticated;

DROP POLICY IF EXISTS bm_attach_read ON public.bm_chat_attachments;
CREATE POLICY bm_attach_read ON public.bm_chat_attachments FOR SELECT TO authenticated
USING (public.bm_chat_message_participant(message_id));
DROP POLICY IF EXISTS bm_attach_insert ON public.bm_chat_attachments;
CREATE POLICY bm_attach_insert ON public.bm_chat_attachments FOR INSERT TO authenticated
WITH CHECK (
 sender_id=(SELECT auth.uid())
 AND EXISTS(SELECT 1 FROM public.messages m WHERE m.id::text=message_id
 AND m.sender_id=(SELECT auth.uid()) AND m.recipient_id=bm_chat_attachments.recipient_id)
 AND split_part(storage_path,'/',1)=(SELECT auth.uid())::text
 AND split_part(storage_path,'/',2)=message_id
 AND ((mime_type LIKE 'image/%' AND size_bytes<=8388608)
 OR (mime_type LIKE 'video/%' AND size_bytes<=31457280))
);

INSERT INTO storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
VALUES ('bm-chat-private','bm-chat-private',false,31457280,
 ARRAY['image/jpeg','image/png','image/webp','video/mp4','video/webm'])
ON CONFLICT(id) DO UPDATE SET public=false,file_size_limit=31457280,
allowed_mime_types=EXCLUDED.allowed_mime_types;

DROP POLICY IF EXISTS bm_chat_storage_upload ON storage.objects;
CREATE POLICY bm_chat_storage_upload ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id='bm-chat-private' AND (storage.foldername(name))[1]=(SELECT auth.uid())::text
 AND EXISTS(SELECT 1 FROM public.messages m WHERE m.id::text=(storage.foldername(name))[2]
 AND m.sender_id=(SELECT auth.uid())));
DROP POLICY IF EXISTS bm_chat_storage_read ON storage.objects;
CREATE POLICY bm_chat_storage_read ON storage.objects FOR SELECT TO authenticated
USING (bucket_id='bm-chat-private' AND EXISTS(
 SELECT 1 FROM public.bm_chat_attachments a WHERE a.storage_path=name
 AND public.bm_chat_message_participant(a.message_id)));

CREATE TABLE IF NOT EXISTS public.bm_calls (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 caller_id uuid NOT NULL REFERENCES auth.users(id),
 callee_id uuid NOT NULL REFERENCES auth.users(id),
 kind text NOT NULL CHECK(kind IN ('audio','video')),
 status text NOT NULL DEFAULT 'ringing' CHECK(status IN ('ringing','accepted','rejected','ended')),
 offer text, answer text,
 created_at timestamptz NOT NULL DEFAULT now(),
 CHECK(caller_id<>callee_id)
);
ALTER TABLE public.bm_calls ENABLE ROW LEVEL SECURITY;
CREATE INDEX IF NOT EXISTS bm_calls_callee_idx ON public.bm_calls(callee_id,status,created_at DESC);
DROP POLICY IF EXISTS bm_calls_select ON public.bm_calls;
CREATE POLICY bm_calls_select ON public.bm_calls FOR SELECT TO authenticated
USING ((SELECT auth.uid()) IN (caller_id,callee_id));
DROP POLICY IF EXISTS bm_calls_insert ON public.bm_calls;
CREATE POLICY bm_calls_insert ON public.bm_calls FOR INSERT TO authenticated
WITH CHECK (caller_id=(SELECT auth.uid()) AND status='ringing' AND offer IS NULL AND answer IS NULL);
DROP POLICY IF EXISTS bm_calls_update ON public.bm_calls;
CREATE POLICY bm_calls_update ON public.bm_calls FOR UPDATE TO authenticated
USING ((SELECT auth.uid()) IN (caller_id,callee_id))
WITH CHECK ((SELECT auth.uid()) IN (caller_id,callee_id));

CREATE TABLE IF NOT EXISTS public.bm_call_ice (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 call_id uuid NOT NULL REFERENCES public.bm_calls(id) ON DELETE CASCADE,
 user_id uuid NOT NULL REFERENCES auth.users(id),
 candidate text NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.bm_call_ice ENABLE ROW LEVEL SECURITY;
CREATE INDEX IF NOT EXISTS bm_call_ice_call_idx ON public.bm_call_ice(call_id,id);
DROP POLICY IF EXISTS bm_call_ice_select ON public.bm_call_ice;
CREATE POLICY bm_call_ice_select ON public.bm_call_ice FOR SELECT TO authenticated
USING (EXISTS(SELECT 1 FROM public.bm_calls c WHERE c.id=call_id
 AND (SELECT auth.uid()) IN (c.caller_id,c.callee_id)));
DROP POLICY IF EXISTS bm_call_ice_insert ON public.bm_call_ice;
CREATE POLICY bm_call_ice_insert ON public.bm_call_ice FOR INSERT TO authenticated
WITH CHECK (user_id=(SELECT auth.uid()) AND EXISTS(
 SELECT 1 FROM public.bm_calls c WHERE c.id=call_id
 AND (SELECT auth.uid()) IN (c.caller_id,c.callee_id)));

-- RESTREINDRE LA MUTATION DES OFFRES/REPONSES WEBRTC :
-- Le navigateur actuel necessite UPDATE; pour la production remplacer par RPC
-- verifiant caller_id pour offer et callee_id pour answer.
-- Les anciennes politiques de public.messages doivent aussi restreindre
-- SELECT/INSERT/UPDATE aux participants. Ce script ne les remplace pas.
SELECT 'V3 tables created' AS result;
